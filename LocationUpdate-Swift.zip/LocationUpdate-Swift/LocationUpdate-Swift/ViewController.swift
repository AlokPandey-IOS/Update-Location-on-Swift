//
//  ViewController.swift
//  LocationUpdate-Swift
//
//  Created by Alok  on 6/27/16.
//  Copyright © 2016 alok. All rights reserved.
//

import UIKit
import CoreLocation
class ViewController: UIViewController ,CLLocationManagerDelegate {
var locationManager = CLLocationManager()
    override func viewDidLoad() {
        super.viewDidLoad()
       self.updateMyLocation()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK- Update Location 
    func updateMyLocation(){
        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyThreeKilometers;
        if locationManager.respondsToSelector(#selector(CLLocationManager.requestWhenInUseAuthorization)){
           locationManager.requestWhenInUseAuthorization()
        }
        else{
            locationManager.startUpdatingLocation()
        }
    }
    //MARK: Location Update
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
        NSLog("Error to update location :%@",error)
    }
    func locationManager(manager: CLLocationManager, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        switch status {
        case .NotDetermined: break
        case .Restricted: break
        case .Denied:
                NSLog("do some error handling")
            break
        default:
            locationManager.startUpdatingLocation()
        }
    }
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
         let location = locations.last! as CLLocation
        var latitude = location.coordinate.latitude
        var longitude = location.coordinate.longitude
        
    }

}

